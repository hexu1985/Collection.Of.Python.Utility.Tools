#! /usr/bin/env python3

from aksetup_helper import configure_frontend
configure_frontend()
